package com.secrethq.ads;
import org.cocos2dx.lib.Cocos2dxActivity;
import android.app.Activity;

public class PTAdChartboostBridge {
	public static void initBridge(Cocos2dxActivity activity){
	}
	
	public static void cacheInterstitial(final String location) {
	}
	
	public static void showInterstitial() {
	}
	
	public static void showInterstitial(final String location) {
	}

	public static void onResume( Activity act){
	}

	public static void onStart( Activity act){
	}

	public static void onStop( Activity act){
	}
}
